$(document).ready(function() {
    $("#BGM").get(0).play();
});

function toggleBGM(button) {
  if (button.value == "OFF") {
    button.value = "ON";
	button.style.backgroundColor = "Green";
	document.getElementById("BGM").play();
	// document.getElementById("BGM").muted = false;
  } else {
    button.value = "OFF";
	button.style.backgroundColor = "Red";
	document.getElementById("BGM").pause();
	// document.getElementById("BGM"). = true;
  }
}

function playSFX(){
	document.getElementById("SFX").play();
}

function toggleSFX(button) {
  if (button.value == "OFF") {
    button.value = "ON";
	button.style.backgroundColor = "Green";
	document.getElementById("SFX").muted = false;
  } else {
    button.value = "OFF";
	button.style.backgroundColor = "Red";
	document.getElementById("SFX").muted = true;
  }
}