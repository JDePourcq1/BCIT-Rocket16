/*
    Signing in and Signing up.
*/

var currentUser = null;

//sign up: 
var signUp = function() {
    var user = document.getElementById("Username").value;
    var email = document.getElementById("E-Mail").value;
    var pass = document.getElementById("Password").value;
    
    $.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/User?apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
        dataType: 'json',
        success: function (data) {
            for(i = 0; i < data.length; i++) {
                if(user.toLowerCase() == (data[i].username).toLowerCase()) {
                    alert("Username Already Taken!");
                    return false;
                }
            }
            
            $.ajax( { url: "https://api.mlab.com/api/1/databases/kitty_cat_database/collections/User?apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB",
                async: false,
                data: JSON.stringify( { "username": user,
                                        "email": email,
                                        "password": pass} ),
                type: "POST",
                contentType: "application/json" } 
            );
            $("#signForm")[0].reset();
            alert("New User Created!");
        }
    });
    return false;
}

var logIn = function () {
    var user = document.getElementById("logUser").value;
    var pass = document.getElementById("logPassword").value;
    
    $.ajax({
        async: false,
        type: 'GET',
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/User?apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB',
        dataType: 'json',
        success: function(data) {
            for(i = 0; i < data.length; i++) {
                if(user.toLowerCase() == (data[i].username).toLowerCase()) {
                    if(pass == data[i].password) {
                        currentUser = data[i].username;
                        document.getElementById("user").innerHTML = "<p>" + currentUser +"</p>";
                        $("#logForm")[0].reset();
                        return false;
                    }
                }
            }
            alert("Invalid User Data");
        }
    });
    return false;
}

// retrieve score for leaderboard
var getLeaderboard = function () {
	
	var names = new Array(10);
	var min = new Array(10);
	var sec = new Array(10);
	var mil = new Array(10);
	var score = new Array(10);
	
    $.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?s=%7B%22score.min%22%3A%201%2C%20%22score.sec%22%3A%201%2C%20%22score.mil%22%3A%201%7D&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			for(i = 0; i < 10; i++) {
				names[i] = data[i].username;	
				min[i] = data[i].score.min;
				sec[i] = data[i].score.sec;
				mil[i] = data[i].score.mil;
				score[i] = Math.ceil((4000000 - (min[i] * 60 * 100 + sec[i] * 100 + mil[i])) / 1000);
			}
		}
	});
	
	document.getElementById("topTen").innerHTML 
		= "<tr><th>Name</th><th>Time</th><th>Score</td></tr>"
		+ "<tr><td>" + names[0] + "</td>" + "<td>" + min[0] + ":" + sec[0] + ":" + mil[0] 
		+ "</td>" + "<td>" + score[0] + "</td></tr>"
		+ "<tr><td>" + names[1] + "</td>" + "<td>" + min[1] + ":" + sec[1] + ":" + mil[1] 
		+ "</td>" + "<td>" + score[1] + "</td></tr>"
		+ "<tr><td>" + names[2] + "</td>" + "<td>" + min[2] + ":" + sec[2] + ":" + mil[2] 
		+ "</td>" + "<td>" + score[2] + "</td></tr>"
		+ "<tr><td>" + names[3] + "</td>" + "<td>" + min[3] + ":" + sec[3] + ":" + mil[3] 
		+ "</td>" + "<td>" + score[3] + "</td></tr>"
		+ "<tr><td>" + names[4] + "</td>" + "<td>" + min[4] + ":" + sec[4] + ":" + mil[4] 
		+ "</td>" + "<td>" + score[4] + "</td></tr>"
		+ "<tr><td>" + names[5] + "</td>" + "<td>" + min[5] + ":" + sec[5] + ":" + mil[5] 
		+ "</td>" + "<td>" + score[5] + "</td></tr>"
		+ "<tr><td>" + names[6] + "</td>" + "<td>" + min[6] + ":" + sec[6] + ":" + mil[6] 
		+ "</td>" + "<td>" + score[6] + "</td></tr>"
		+ "<tr><td>" + names[7] + "</td>" + "<td>" + min[7] + ":" + sec[7] + ":" + mil[7] 
		+ "</td>" + "<td>" + score[7] + "</td></tr>"
		+ "<tr><td>" + names[8] + "</td>" + "<td>" + min[8] + ":" + sec[8] + ":" + mil[8] 
		+ "</td>" + "<td>" + score[8] + "</td></tr>"
		+ "<tr><td>" + names[9] + "</td>" + "<td>" + min[9] + ":" + sec[9] + ":" + mil[9] 
		+ "</td>" + "<td>" + score[9] + "</td></tr>";

}

//retrieve course times for profile page	
var getCourseScores = function () {
	
	var courseCount = 0;
	var courseMin = new Array(5);
	var courseSec = new Array(5);
	var courseMil = new Array(5);
	
	currentUser = "Karl";
	
	$.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?q={"username": "'+currentUser+'", "courseID":"1"}&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			if(data.length > 0) {
				courseCount++;
				courseMin[0] = data[0].score.min;
				courseSec[0] = data[0].score.sec;
				courseMil[0] = data[0].score.mil;
			}
		}	
	});
	
	$.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?q={"username":"'+currentUser+'", "courseID":"2"}&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			if(data.length > 0) {
				courseCount++;
				courseMin[1] = data[0].score.min;
				courseSec[1] = data[0].score.sec;
				courseMil[1] = data[0].score.mil;
			}
		}	
	});
	
	$.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?q={"username":"'+currentUser+'", "courseID":"3"}&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			if(data.length > 0) {
				courseCount++;
				courseMin[2] = data[0].score.min;
				courseSec[2] = data[0].score.sec;
				courseMil[2] = data[0].score.mil;
			}
		}	
	});
	
	$.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?q={"username":"'+currentUser+'", "courseID":"3"}&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			if(data.length > 0) {
				courseCount++;
				courseMin[3] = data[0].score.min;
				courseSec[3] = data[0].score.sec;
				courseMil[3] = data[0].score.mil;
			}
		}	
	});
	
	$.ajax({
        async: false,
        type: 'GET', 
        url: 'https://api.mlab.com/api/1/databases/kitty_cat_database/collections/Score?q={"username":"'+currentUser+'", "courseID":"3"}&apiKey=AMVdmMQFjEHmgWz3ppXtWHqCaOaBm2XB', 
		dataType: 'json',
        success: function(data) {
			if(data.length > 0) {
				courseCount++;
				courseMin[4] = data[0].score.min;
				courseSec[4] = data[0].score.sec;
				courseMil[4] = data[0].score.mil;
			}
		}	
	});
	
	if(courseCount == 1) {
		document.getElementById("results").innerHTML 
		= "<tr><th>Course</th><th>Time</th></tr>"
		+ "<tr><td>Course1</td><td>" + courseMin[0] + ":" + courseSec[0] + ":" + courseMil[0] + "</td></tr>";
	}
	
	if(courseCount == 2) {
		document.getElementById("results").innerHTML 
		= "<tr><th>Course</th><th>Time</th></tr>"
		+ "<tr><td>Course1</td><td>" + courseMin[0] + ":" + courseSec[0] + ":" + courseMil[0] + "</td></tr>"
		+ "<tr><td>Course2</td><td>" + courseMin[1] + ":" + courseSec[1] + ":" + courseMil[1] + "</td></tr>";
	}
	
	if(courseCount == 3) {
		document.getElementById("results").innerHTML 
		= "<tr><th>Course</th><th>Time</th></tr>"
		+ "<tr><td>Course1</td><td>" + courseMin[0] + ":" + courseSec[0] + ":" + courseMil[0] + "</td></tr>"
		+ "<tr><td>Course2</td><td>" + courseMin[1] + ":" + courseSec[1] + ":" + courseMil[1] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[2] + ":" + courseSec[2] + ":" + courseMil[2] + "</td></tr>";
	}
	
	if(courseCount == 4) {
		document.getElementById("results").innerHTML 
		= "<tr><th>Course</th><th>Time</th></tr>"
		+ "<tr><td>Course1</td><td>" + courseMin[0] + ":" + courseSec[0] + ":" + courseMil[0] + "</td></tr>"
		+ "<tr><td>Course2</td><td>" + courseMin[1] + ":" + courseSec[1] + ":" + courseMil[1] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[2] + ":" + courseSec[2] + ":" + courseMil[2] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[3] + ":" + courseSec[3] + ":" + courseMil[3] + "</td></tr>";
	}
	
	if(courseCount == 5) {
		document.getElementById("results").innerHTML 
		= "<tr><th>Course</th><th>Time</th></tr>"
		+ "<tr><td>Course1</td><td>" + courseMin[0] + ":" + courseSec[0] + ":" + courseMil[0] + "</td></tr>"
		+ "<tr><td>Course2</td><td>" + courseMin[1] + ":" + courseSec[1] + ":" + courseMil[1] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[2] + ":" + courseSec[2] + ":" + courseMil[2] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[3] + ":" + courseSec[3] + ":" + courseMil[3] + "</td></tr>"
		+ "<tr><td>Course3</td><td>" + courseMin[4] + ":" + courseSec[4] + ":" + courseMil[4] + "</td></tr>";
	}
	
}