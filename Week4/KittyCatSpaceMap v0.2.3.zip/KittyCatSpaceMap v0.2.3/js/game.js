//setupMap(2);
//randomObjectives();
paper.install(window);
window.onload = function() {
	paper.setup('testCanvas');
	setupMap(0);
}