//------------------------------------------------------------
//     100% Canadian Hamburger Button
//------------------------------------------------------------
var menuOpen = false;
var playerMoving = false;
var buttonNames = ["MAIN-MENU", "COURSE-SELECT", "PROFILE", "SETTINGS", "BACK"];

function openMenu() {
    if (menuOpen == false) {
        menuOpen = true;
        disable();
        var menu = document.createElement('div');
        var myButton = document.createElement('button');
        
        if(gameplay) {
            pauseGame();
        } else {
            if(count > 0) {
                startCountDown();
            }
        }
        
        menu.id = "menu";
        for(i = 0; i < buttonNames.length; i++, myButton = document.createElement('button')) {
            myButton.type = "button";
            myButton.className = "btn center-block menuButton";
            myButton.innerHTML = buttonNames[i];
            myButton.id = buttonNames[i];
            menu.appendChild(myButton);
            menu.appendChild(document.createElement('br'));
        }
        document.getElementById('menuDiv').appendChild(menu);
        
    } else {
        goBack();
    }
}

function goBack() {
    menuOpen = false;
    unlock();
    if(gameplay) {
        pauseGame();
    }
    document.getElementById('menuDiv').removeChild(document.getElementById('menu'));
}

function goToProfile() {
    if(menuOpen) {
        openMenu();
    }
    document.getElementById('usernameHeader').innerHTML = currentUser;
    getCourseScores();
    $('#mainPage').attr('style', 'display: none;');
    $('#courseSelect').attr('style', 'display: none;');
    $('#loginPage').attr('style', 'display: none;');
    $('#gameScreen').attr('style', 'display: none;');
    $('#leaderboard').attr('style', 'display: none;');
    $('#profilePage').attr('style', 'display: ;');
    $('#resultsPage').attr('style', 'display: none;');
    
}

$(document).ready(function(){
    //when launch is clicked
    $('#Launch').click(function(){
        if (!menuOpen) {
            $('#mainPage').attr('style', 'display: none;');
            $('#courseSelect').attr('style', 'display: ;');
            $('#loginPage').attr('style', 'display: none;');
            $('#gameScreen').attr('style', 'display: none;');
            $('#leaderboard').attr('style', 'display: none;');
            $('#profilePage').attr('style', 'display: none;');
            $('#resultsPage').attr('style', 'display: none;');
        }
    });

    //when nose is clicked
    $('#nose').dblclick(function(){
        if(easterEnabled) {
            easterEnabled = false;
            alert("EASTER EGG DEACTIVATED.");
        } else {
            easterEnabled = true;
            alert("EASTER EGG ACTIVATED.");
        }
    });
	
	//activate cat traveller
	$('#carouselItem1').click(function(){
		alert("ROCKET CAT ACTIVATED.");
	});
    
    //user button
    $('#User').click(function() {
        if(currentUser == null) {
            $('#mainPage').attr('style', 'display: none;');
            $('#courseSelect').attr('style', 'display: none;');
            $('#loginPage').attr('style', 'display: ;');
            $('#gameScreen').attr('style', 'display: none;');
            $('#leaderboard').attr('style', 'display: none;');
            $('#profilePage').attr('style', 'display: none;');
            $('#resultsPage').attr('style', 'display: none;');
            if(menuOpen)
                openMenu();
        } else {
            goToProfile();
        }
    });
    
    $('div').on('click', 'button#PROFILE', function() {
        if(currentUser == null) {
            $('#mainPage').attr('style', 'display: none;');
            $('#courseSelect').attr('style', 'display: none;');
            $('#loginPage').attr('style', 'display: ;');
            $('#gameScreen').attr('style', 'display: none;');
            $('#leaderboard').attr('style', 'display: none;');
            $('#profilePage').attr('style', 'display: none;');
            $('#resultsPage').attr('style', 'display: none;');
            stopGame();
            openMenu();
        } else {
            goToProfile();
        }
    });
    

    //main menu button
    $('div').on('click', 'button#MAIN-MENU', function() {
        $('#mainPage').attr('style', 'display: ;');
        $('#courseSelect').attr('style', 'display: none;');
        $('#loginPage').attr('style', 'display: none;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: none;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        stopGame();
        openMenu();
    });
    
    //back button
    $(".return").click(function() {
        $('#mainPage').attr('style', 'display: ;');
        $('#courseSelect').attr('style', 'display: none;');
        $('#loginPage').attr('style', 'display: none;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: none;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        if(menuOpen)
            openMenu();
    });

    //course select button
    $('div').on('click', 'button#COURSE-SELECT', function() {
        $('#mainPage').attr('style', 'display: none;');
        $('#courseSelect').attr('style', 'display: ;');
        $('#loginPage').attr('style', 'display: none;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: none;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        stopGame();
        openMenu();
    });
    
    //settings button
    $('div').on('click', 'button#SETTINGS', function() {
		$('#settingsPage').attr('style', 'display: ;');
        $('#menuDiv').hide();
		openMenu();
		pauseGame();
		
    });
    
    //burger click
    $(".burger").click(function() {
        if(myTimer == null && !playerMoving) {
            openMenu();
        }
    });
    
    //back menu button
    $("#menuDiv").on('click', 'button#BACK', function() {
        goBack();
    });
    
    //leader button click
    $('.leader').click(function() {
        setupLeaderboard(0);
        $('#mainPage').attr('style', 'display: none;');
        $('#courseSelect').attr('style', 'display: none;');
        $('#loginPage').attr('style', 'display: none;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: ;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        if (menuOpen) {
            openMenu();
        }
    });
    
    //sign out button
    $('#signout').click(function() {
        currentUser = null;
        document.getElementById("username").innerHTML = "";
        document.getElementById('profileButton').innerHTML = "Sign-In";
        $('#mainPage').attr('style', 'display: none;');
        $('#courseSelect').attr('style', 'display: none;');
        $('#loginPage').attr('style', 'display: ;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: none;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        if(menuOpen)
            openMenu();
    });
    
    //profile/signin button
    $('#profileButton').click(function() {
        if(currentUser == null) {
            $('#mainPage').attr('style', 'display: none;');
            $('#courseSelect').attr('style', 'display: none;');
            $('#loginPage').attr('style', 'display: ;');
            $('#gameScreen').attr('style', 'display: none;');
            $('#leaderboard').attr('style', 'display: none;');
            $('#profilePage').attr('style', 'display: none;');
            $('#resultsPage').attr('style', 'display: none;');
            if (menuOpen)
                openMenu();
        } else {
            goToProfile();
        }
    });
    
    //retry button
    $('#retryButton').click(function() {
        document.getElementById("course01").click();
    });
    
    //continue button
    $('#continueButton').click(function() {
        $('#mainPage').attr('style', 'display: none;');
        $('#courseSelect').attr('style', 'display: ;');
        $('#loginPage').attr('style', 'display: none;');
        $('#gameScreen').attr('style', 'display: none;');
        $('#leaderboard').attr('style', 'display: none;');
        $('#profilePage').attr('style', 'display: none;');
        $('#resultsPage').attr('style', 'display: none;');
        if (menuOpen)
            openMenu();
    });
	
	//unlock traveller
	var travellerScore = 0;
	
	$('#test').click(function(){
		unlockTraveller(1); 
	});
	
	var unlockTraveller = function(traveller) {
		
		if (traveller == 1) {
			$('#item1Lock').attr('style', 'display: none;');
			$('#item1').attr('style', 'display: block;');
			 
			$('#carouselItem2').click(function(){
				alert("BASIC ROCKET ACTIVATED.");
			});
		} else if (traveller == 2) {
			$('#item2Lock').attr('style', 'display: none;');
			$('#item2').attr('style', 'display: block;');
			
			$('#carouselItem3').click(function(){
				alert("ROCKET DOG ACTIVATED.");
			});
		} else if (traveller == 3) {
			$('#item3Lock').attr('style', 'display: none;');
			$('#item3').attr('style', 'display: block;');
			
			$('#carouselItem4').click(function(){
				alert("ROCKET RACCOON ACTIVATED.");
			});
		} else if (traveller == 4) {
			$('#item4Lock').attr('style', 'display: none;');
			$('#item4').attr('style', 'display: block;');
			
			$('#carouselItem5').click(function(){
				alert("ROCKET BUNNY ACTIVATED.");
			});
		} else if (traveller == 5) {
			$('#item5Lock').attr('style', 'display: none;');
			$('#item5').attr('style', 'display: block;');
			 
			$('#carouselItem6').click(function(){
				alert("GOLDEN ROCKET ACTIVATED.");
			});
		} else {
			$('#item6Lock').attr('style', 'display: none;');
			$('#item6').attr('style', 'display: block;');
			
			$('#carouselItem7').click(function(){
				alert("EASTER EGG ACTIVATED.");
			});
		} 
	}
});